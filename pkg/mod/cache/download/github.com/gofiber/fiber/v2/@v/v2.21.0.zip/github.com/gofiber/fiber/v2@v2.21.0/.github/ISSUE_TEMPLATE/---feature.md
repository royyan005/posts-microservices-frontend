---
name: "\U0001F680 Feature"
about: Suggest an idea for this project
title: "\U0001F680 "
labels: 'Type: Feature'
assignees: ''

---

**Is your feature request related to a problem?**

**Describe the solution you'd like**

**Describe alternatives you've considered**

**Additional context**
